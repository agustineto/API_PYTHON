class Solicitud:
    def constructor(self, cve_usuario, ingreso, gasto, ine_inverso, ine_anverso):
        self.cve_usuario = cve_usuario
        self.ingreso = ingreso
        self.gasto = gasto
        self.ine_inverso = ine_inverso
        self.ine_anverso = ine_anverso